from setuptools import setup

setup(name='hmp_distributions',
      version='0.2',
      description='Gaussian distributions',
      packages=['hmp_distributions'],
      author='Henrique M. Prado',
      author_email='hmartins.prado@gmail.com',
      zip_safe=False)
